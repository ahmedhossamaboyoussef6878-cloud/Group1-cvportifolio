#!/bin/bash

FILE="cv-ahmed.html"

if [ ! -f "$FILE" ]; then
  echo "Error: $FILE was not found in the current directory."
  echo "Please run this script from the main project folder."
  exit 1
fi

echo "HTML Tag Analysis for $FILE"
echo "--------------------------------"
echo "Number of <div> tags: $(grep -oi '<div\b' "$FILE" | wc -l)"
echo "Number of <img> tags: $(grep -oi '<img\b' "$FILE" | wc -l)"
echo "Number of <a> links: $(grep -oi '<a\b' "$FILE" | wc -l)"
echo "Number of heading tags <h1> to <h6>: $(grep -Eoi '<h[1-6]\b' "$FILE" | wc -l)"
echo "--------------------------------"
echo "Analysis complete."
