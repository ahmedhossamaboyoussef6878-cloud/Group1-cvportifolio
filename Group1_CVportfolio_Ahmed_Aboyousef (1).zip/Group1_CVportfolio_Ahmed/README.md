# CV Portfolio Website

## Project Description
This project is a professional CV portfolio website created for the Computer Science Ecosystems coursework. It demonstrates the use of HTML, CSS, JavaScript, GitHub, and Bash scripting in one small web development project.

The website includes:
- A creative homepage with motivation for the project
- A CV page for Ahmed Aboyousef
- One shared CSS file for styling all HTML pages
- JavaScript interactivity
- A Bash script that analyses the CV HTML file and counts selected HTML tags

## Team Member
- Ahmed Aboyousef

## File Structure
```text
Group1_CVportfolio/
├── index.html
├── cv-ahmed.html
├── style.css
├── script.js
├── Ahmed_bash.sh
├── assets/
│   └── avatar-ahmed.svg
├── screenshots/
│   └── Ahmed_bash_output.png
└── README.md
```

## How to Run the Website Locally
1. Download or clone the repository.
2. Open the project folder in a text editor such as VS Code.
3. Open `index.html` in a web browser.
4. Use the navigation bar to open the CV page.

## JavaScript Features
The project includes more than two simple JavaScript features:
1. Change theme button
2. Show current date and time button
3. Show/hide CV sections
4. Interactive social media buttons

## How to Run the Bash Script
Open the terminal inside the main project folder and run:

```bash
chmod +x Ahmed_bash.sh
./Ahmed_bash.sh
```

The script counts:
- `<div>` tags
- `<img>` tags
- `<a>` links
- Heading tags from `<h1>` to `<h6>`

## Third-Party Libraries or Resources
No third-party libraries were used. The project uses plain HTML, CSS, JavaScript, and Bash.
