const themeButtons = document.querySelectorAll('#themeToggle');
const dateButton = document.getElementById('showDateBtn');
const dateOutput = document.getElementById('dateOutput');
const sectionButtons = document.querySelectorAll('.toggle-section');
const socialButtons = document.querySelectorAll('.social-btn');

themeButtons.forEach((button) => {
  button.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
  });
});

if (dateButton && dateOutput) {
  dateButton.addEventListener('click', () => {
    const currentDate = new Date();
    dateOutput.textContent = `Current date and time: ${currentDate.toLocaleString()}`;
  });
}

sectionButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const section = button.closest('.cv-section');
    const body = section.querySelector('.section-body');
    body.classList.toggle('hidden');
  });
});

socialButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const platform = button.dataset.platform;
    alert(`This button can link to your ${platform} profile.`);
  });
});
